import React from 'react'
import { height } from '@material-ui/system';
import {
    Route,
    NavLink,
    BrowserRouter as Router,
    Switch,
  } from 'react-router-dom';

class Home extends React.Component {

    render() {
        return (

            <div style={{ margin: "auto", width: "80%" }}>
                <br></br><br></br>
                <NavLink to="/doctor"><div style={{ width: "170px", height: "170px", float: "left", backgroundColor: "#ddd", padding: "10px", margin: "10px" }}>
                    Doctor</div></NavLink>
                    <NavLink to="/user"><div style={{ width: "170px", height: "170px", float: "left", backgroundColor: "#ddd", padding: "10px", margin: "10px" }}>
                    User</div></NavLink>

            </div>
        );
    };


}

export default Home;