import React from 'react'
import PaperSheet from './paper';
import { Paper } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
const useStyles = makeStyles(theme => ({
    container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    textField: {
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
        width: 200,
    },
}));

class SubmitVac extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            name: "",
            lic: "",
            pName: "",
            bc: "",
            vacText: ""
        };
        this.handleNewUser = this.handleNewUser.bind(this);
    }
    /**
     * {"success":true,"secret":"EkMHsNknuWmp","message":"id-admin enrolled Successfully","token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1NzMzNTY5NzgsInVzZXJuYW1lIjoiaWQtYWRtaW4iLCJvcmdOYW1lIjoiaWQtdXMiLCJpYXQiOjE1NzMzMjA5Nzh9.UPR8TJzOhqxw1RYOBwHTbZ4EPXsIGQp_t-lOjac3XVk"}
     * 
     */
    getTockenAndRegisterUser() {
        if (this.state.tocken !== "") {
            fetch('http://localhost:4000/users', {
                method: "POST",
                body: '{"username":"id-admin"}'
            }).then((response) => {
                if (response.status === 200) {
                    response.json().then((data) => {
                        this.setState({
                            tocken: data.token
                        })
                        this.registerUser(data.token);
                    });
                }
            });
        } else {
            this.registerUser(this.setState.token);
        }

    }
    /**
     * 
     * @param {{"peers":["id-us/peer0"],"fcn":"register","args":["name1","father_name","mother_name","entity_access","passport","ssn","bc"]}} tocken 
     */
    registerUser(tocken) {
        const toPost = {};
        const arr = [];
        arr.push(this.state.name);
        arr.push(this.state.fathersName);
        arr.push(this.state.mothersName);
        arr.push(this.state.orgName);
        arr.push(this.state.passport);
        arr.push(this.state.ssn);
        arr.push(this.state.dob);
        toPost.peers = '["id-us/peer0"]';
        toPost.fcn = "register";
        toPost.args = arr;

        console.log(toPost);
        const headerWithtocken = {
            "Authorization": "Bearer " + tocken
        }
        if(tocken!== "")
        fetch('http://localhost:4000/channels/vaccination-us/chaincodes/identity-register', {
            method: "POST",
            headers: headerWithtocken,
            body: toPost
        }
        )
    }


    handleNewUser() {
        console.log(this.state);
        this.registerUser("");
    }

    change(evt) {
        switch (evt.target.id) {
            case "txt_name":
                this.setState({
                    name: evt.target.value
                });
                break
            case "txt_lic":
                this.setState({
                    lic: evt.target.value
                });
                break
            case "txt_patient":
                this.setState({
                    pName: evt.target.value
                });
                break
            case "txt_bc":
                this.setState({
                    bc: evt.target.value
                });
                break
            case "txt_vac":
                this.setState({
                    vacText: evt.target.value
                });
                break;
        }
        console.log(evt.target.id);
    }
    render() {
        return (
            <div style={{ margin: "auto", width: "80%" }}>
                <br></br><br></br>
                <PaperSheet>
                    <span style={{ fontSize: "26px" }}> User Registration</span>

                    <br></br>
                    <TextField
                        id="txt_name"
                        label="Dr's Full Name:"
                        style={{ margin: 8 }}
                        placeholder="Enter your Full Name"
                        style={{ width: "400px" }}
                        margin="normal"
                        value={this.state.name}
                        onChange={this.change.bind(this)}
                        InputLabelProps={{
                            shrink: true,
                        }}
                    />
                    <br></br>
                    <TextField
                        id="txt_lic"
                        label="License:"
                        style={{ margin: 8 }}
                        placeholder="Enter License number (123132132134)"
                        style={{ width: "400px" }}
                        margin="normal"
                        value={this.state.lic}
                        InputLabelProps={{
                            shrink: true,
                        }}
                        onChange={this.change.bind(this)}
                    />

                    <br></br>
                    <TextField
                        id="txt_patient"
                        label="Patient's name:"
                        style={{ margin: 8 }}
                        placeholder="Enter Patient's name"
                        style={{ width: "400px" }}
                        margin="normal"
                        value={this.state.pName}
                        InputLabelProps={{
                            shrink: true,
                        }} onChange={this.change.bind(this)}
                    />

                    <br></br>
                    <TextField
                        id="txt_bc"
                        label="Birth Identifier:"
                        style={{ margin: 8 }}
                        placeholder="Enter Birth Identifier of patient"
                        style={{ width: "400px" }}
                        margin="normal"
                        value={this.state.bc}
                        InputLabelProps={{
                            shrink: true,
                        }} onChange={this.change.bind(this)}
                    />

                    <br></br>
                    <TextField
                        id="txt_vac"
                        label="Vaccination Type:"
                        style={{ margin: 8 }}
                        placeholder="Enter Vaccination type "
                        style={{ width: "400px" }}
                        margin="normal"
                        value={this.state.vacText}
                        InputLabelProps={{
                            shrink: true,
                        }} onChange={this.change.bind(this)}
                    />
                  
                    <br /><br />
                    <Button variant="contained" color="primary" style={{ margin: "1" }} onClick={this.handleNewUser}>
                        Submit
      </Button>

                </PaperSheet>
            </div>

        );
    }
}
export default SubmitVac